// telegram-app-backend/server.js
const express = require('express');
const cors = require('cors');
require('dotenv').config();

// =================================================================
// STEP 1: Require all route files first. This part is safe.
// =================================================================
const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const cartRoutes = require('./routes/cart');
const orderRoutes = require('./routes/orders');
const userRoutes = require('./routes/user');
const cityRoutes = require('./routes/cities');
const supplierRoutes = require('./routes/suppliers');
const dealRoutes = require('./routes/deals');
const searchRoutes = require('./routes/search');
const favoritesRoutes = require('./routes/favorites');
const featuredItemsRoutes = require('./routes/featuredItems');
const deliveryRoutes = require('./routes/delivery');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3001;

// MIDDLEWARE SETUP
const corsOptions = {
    origin: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : [
        'http://localhost:5173', 'http://localhost:5174', 
        'http://localhost:5175', 'http://localhost:5176'
    ],
    credentials: true,
    optionsSuccessStatus: 200
};
app.use(cors(corsOptions));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// =================================================================
// STEP 2: The DEFINITIVE test. We will try to USE each router one by one.
// =================================================================
const routesToUse = [
    { name: 'auth.js', path: '/api/auth', router: authRoutes },
    { name: 'products.js', path: '/api/products', router: productRoutes },
    { name: 'cart.js', path: '/api/cart', router: cartRoutes },
    { name: 'orders.js', path: '/api/orders', router: orderRoutes },
    { name: 'user.js', path: '/api/user', router: userRoutes },
    { name: 'cities.js', path: '/api/cities', router: cityRoutes },
    { name: 'suppliers.js', path: '/api/suppliers', router: supplierRoutes },
    { name: 'deals.js', path: '/api/deals', router: dealRoutes },
    { name: 'search.js', path: '/api/search', router: searchRoutes },
    { name: 'favorites.js', path: '/api/favorites', router: favoritesRoutes },
    { name: 'featuredItems.js', path: '/api/featured-items', router: featuredItemsRoutes },
    { name: 'delivery.js', path: '/api/delivery', router: deliveryRoutes },
    { name: 'admin.js', path: '/api/admin', router: adminRoutes },
];

console.log('Attempting to apply routes...');
routesToUse.forEach(routeInfo => {
    try {
        app.use(routeInfo.path, routeInfo.router);
        console.log(`✅ Successfully applied routes from: ${routeInfo.name}`);
    } catch (error) {
        console.error(`\n🚨🚨🚨 FATAL ERROR: THE CRASH WAS CAUSED BY THIS FILE: ${routeInfo.name} 🚨🚨🚨`);
        console.error(`The error happened when calling app.use() for the path "${routeInfo.path}".`);
        console.error(`Please open ${routeInfo.name} and look for a typo like '/:' or '/ :id'.\n`);
        console.error('Original Error Stack:');
        console.error(error.stack);
        process.exit(1); // Stop immediately
    }
});
console.log('All routes applied successfully.');

// Health check endpoint (can go here or earlier)
app.get('/health', (req, res) => res.json({ status: 'OK' }));

// Final Error Handlers
app.all('*', (req, res) => res.status(404).json({ error: 'Route not found' }));

app.use((error, req, res, next) => {
    console.error('Global error handler:', error);
    res.status(500).json({ error: 'Internal server error' });
});

console.log('Dumping all registered routes to help find a broken one:');
app._router.stack.forEach((middleware) => {
  if (middleware.route) {
    console.log(`APP ROUTE: ${middleware.route.path}`);
  } else if (middleware.name === 'router') {
    middleware.handle.stack.forEach((handler) => {
      if (handler.route) {
        console.log(`ROUTER ROUTE: ${handler.route.path}`);
      }
    });
  }
});


// SERVER STARTUP
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));


// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('🛑 SIGTERM received, shutting down gracefully...');
    server.close(() => {
        console.log('✅ Process terminated');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('🛑 SIGINT received, shutting down gracefully...');
    server.close(() => {
        console.log('✅ Process terminated');
        process.exit(0);
    });
});

module.exports = app;