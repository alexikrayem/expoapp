// routes/cart.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get user's cart
router.get('/', async (req, res) => {
    try {
        const { userId } = req.query;

        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }

        const query = `
            SELECT 
                c.product_id,
                c.quantity,
                p.name,
                p.price,
                p.discount_price,
                p.is_on_sale,
                p.image_url,
                p.stock_level,
                s.name as supplier_name,
                CASE 
                    WHEN p.is_on_sale = true AND p.discount_price IS NOT NULL 
                    THEN p.discount_price 
                    ELSE p.price 
                END as effective_selling_price
            FROM cart c
            JOIN products p ON c.product_id = p.id
            JOIN suppliers s ON p.supplier_id = s.id
            WHERE c.user_id = $1 AND p.is_active = true
            ORDER BY c.created_at DESC
        `;

        const result = await db.query(query, [userId]);
        res.json(result.rows);

    } catch (error) {
        console.error('Error fetching cart:', error);
        res.status(500).json({ error: 'Failed to fetch cart' });
    }
});

// Add item to cart
router.post('/', async (req, res) => {
    try {
        const { userId, productId, quantity = 1 } = req.body;

        if (!userId || !productId) {
            return res.status(400).json({ error: 'User ID and Product ID are required' });
        }

        // Check if item already exists in cart
        const existingQuery = 'SELECT * FROM cart WHERE user_id = $1 AND product_id = $2';
        const existingResult = await db.query(existingQuery, [userId, productId]);

        if (existingResult.rows.length > 0) {
            // Update quantity
            const newQuantity = existingResult.rows[0].quantity + quantity;
            const updateQuery = 'UPDATE cart SET quantity = $1, updated_at = NOW() WHERE user_id = $2 AND product_id = $3';
            await db.query(updateQuery, [newQuantity, userId, productId]);
        } else {
            // Insert new item
            const insertQuery = 'INSERT INTO cart (user_id, product_id, quantity) VALUES ($1, $2, $3)';
            await db.query(insertQuery, [userId, productId, quantity]);
        }

        res.json({ message: 'Item added to cart successfully' });

    } catch (error) {
        console.error('Error adding to cart:', error);
        res.status(500).json({ error: 'Failed to add item to cart' });
    }
});

// Update cart item quantity
router.put('/item/:productId', async (req, res) => {
    try {
        const { productId } = req.params;
        const { userId } = req.query;
        const { newQuantity } = req.body;

        if (!userId || !newQuantity) {
            return res.status(400).json({ error: 'User ID and new quantity are required' });
        }

        if (newQuantity <= 0) {
            // Remove item if quantity is 0 or less
            const deleteQuery = 'DELETE FROM cart WHERE user_id = $1 AND product_id = $2';
            await db.query(deleteQuery, [userId, productId]);
        } else {
            // Update quantity
            const updateQuery = 'UPDATE cart SET quantity = $1, updated_at = NOW() WHERE user_id = $2 AND product_id = $3';
            await db.query(updateQuery, [newQuantity, userId, productId]);
        }

        res.json({ message: 'Cart updated successfully' });

    } catch (error) {
        console.error('Error updating cart:', error);
        res.status(500).json({ error: 'Failed to update cart' });
    }
});

// Remove item from cart
router.delete('/item/:productId', async (req, res) => {
    try {
        const { productId } = req.params;
        const { userId } = req.query;

        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }

        const deleteQuery = 'DELETE FROM cart WHERE user_id = $1 AND product_id = $2';
        await db.query(deleteQuery, [userId, productId]);

        res.json({ message: 'Item removed from cart successfully' });

    } catch (error) {
        console.error('Error removing from cart:', error);
        res.status(500).json({ error: 'Failed to remove item from cart' });
    }
});

module.exports = router;