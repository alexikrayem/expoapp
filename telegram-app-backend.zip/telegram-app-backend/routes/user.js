// routes/user.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get user profile
router.get('/profile', async (req, res) => {
    try {
        const { userId } = req.query;

        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }

        const query = `
            SELECT 
                up.*,
                c.name as selected_city_name
            FROM user_profiles up
            LEFT JOIN cities c ON up.selected_city_id = c.id
            WHERE up.user_id = $1
        `;

        const result = await db.query(query, [userId]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'User profile not found' });
        }

        res.json(result.rows[0]);

    } catch (error) {
        console.error('Error fetching user profile:', error);
        res.status(500).json({ error: 'Failed to fetch user profile' });
    }
});

// Update user profile
router.post('/profile', async (req, res) => {
    try {
        const { userId, ...profileData } = req.body;

        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }

        // Check if profile exists
        const existingQuery = 'SELECT * FROM user_profiles WHERE user_id = $1';
        const existingResult = await db.query(existingQuery, [userId]);

        if (existingResult.rows.length === 0) {
            // Create new profile
            const insertQuery = `
                INSERT INTO user_profiles (
                    user_id, selected_city_id, full_name, phone_number, 
                    address_line1, address_line2, city
                ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING *
            `;

            const result = await db.query(insertQuery, [
                userId,
                profileData.selected_city_id || null,
                profileData.fullName || profileData.full_name || null,
                profileData.phoneNumber || profileData.phone_number || null,
                profileData.addressLine1 || profileData.address_line1 || null,
                profileData.addressLine2 || profileData.address_line2 || null,
                profileData.city || null
            ]);

            res.json(result.rows[0]);
        } else {
            // Update existing profile
            const updateFields = [];
            const updateValues = [];
            let paramIndex = 1;

            if (profileData.selected_city_id !== undefined) {
                updateFields.push(`selected_city_id = $${paramIndex}`);
                updateValues.push(profileData.selected_city_id);
                paramIndex++;
            }

            if (profileData.fullName || profileData.full_name) {
                updateFields.push(`full_name = $${paramIndex}`);
                updateValues.push(profileData.fullName || profileData.full_name);
                paramIndex++;
            }

            if (profileData.phoneNumber || profileData.phone_number) {
                updateFields.push(`phone_number = $${paramIndex}`);
                updateValues.push(profileData.phoneNumber || profileData.phone_number);
                paramIndex++;
            }

            if (profileData.addressLine1 || profileData.address_line1) {
                updateFields.push(`address_line1 = $${paramIndex}`);
                updateValues.push(profileData.addressLine1 || profileData.address_line1);
                paramIndex++;
            }

            if (profileData.addressLine2 || profileData.address_line2) {
                updateFields.push(`address_line2 = $${paramIndex}`);
                updateValues.push(profileData.addressLine2 || profileData.address_line2);
                paramIndex++;
            }

            if (profileData.city) {
                updateFields.push(`city = $${paramIndex}`);
                updateValues.push(profileData.city);
                paramIndex++;
            }

            if (updateFields.length === 0) {
                return res.json(existingResult.rows[0]);
            }

            updateFields.push(`updated_at = NOW()`);
            updateValues.push(userId);

            const updateQuery = `
                UPDATE user_profiles 
                SET ${updateFields.join(', ')}
                WHERE user_id = $${paramIndex}
                RETURNING *
            `;

            const result = await db.query(updateQuery, updateValues);
            res.json(result.rows[0]);
        }

    } catch (error) {
        console.error('Error updating user profile:', error);
        res.status(500).json({ error: 'Failed to update user profile' });
    }
});

module.exports = router;