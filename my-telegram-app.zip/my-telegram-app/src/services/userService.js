// src/services/userService.js - User-specific API calls
import apiClient from './apiClient';

export const userService = {
    async getProfile(userId) {
        return apiClient.get(`/api/user/profile?userId=${userId}`);
    },

    async updateProfile(userId, profileData) {
        return apiClient.post('/api/user/profile', {
            userId,
            ...profileData,
        });
    },

    async getFavorites(userId) {
        return apiClient.get(`/api/favorites?userId=${userId}`);
    },

    async addFavorite(userId, productId) {
        return apiClient.post('/api/favorites', {
            userId,
            productId,
        });
    },

    async removeFavorite(productId, userId) {
        return apiClient.delete(`/api/favorites/${productId}?userId=${userId}`);
    },
};