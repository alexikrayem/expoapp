// src/services/cityService.js - City-specific API calls
import apiClient from './apiClient';

export const cityService = {
    async getCities() {
        return apiClient.get('/api/cities');
    },

    async getSuppliers(cityId) {
        const params = cityId ? `?cityId=${cityId}` : '';
        return apiClient.get(`/api/suppliers${params}`);
    },

    async getSupplierDetails(supplierId) {
        return apiClient.get(`/api/suppliers/${supplierId}`);
    },

    async getDeals(cityId) {
        const params = cityId ? `?cityId=${cityId}` : '';
        return apiClient.get(`/api/deals${params}`);
    },

    async getDealDetails(dealId) {
        return apiClient.get(`/api/deals/${dealId}`);
    },
};