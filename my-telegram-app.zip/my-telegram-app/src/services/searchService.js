// src/services/searchService.js - Search-specific API calls
import apiClient from './apiClient';

export const searchService = {
    async search(searchTerm, cityId, limit = 10) {
        const params = new URLSearchParams({
            searchTerm,
            limit: limit.toString(),
        });
        
        if (cityId) {
            params.set('cityId', cityId);
        }

        return apiClient.get(`/api/search?${params.toString()}`);
    },
};