// src/services/productService.js - Product-specific API calls
import apiClient from './apiClient';

export const productService = {
    async getProducts(params = {}) {
        const searchParams = new URLSearchParams();
        
        Object.entries(params).forEach(([key, value]) => {
            if (value !== undefined && value !== null && value !== '') {
                searchParams.set(key, value.toString());
            }
        });

        const queryString = searchParams.toString();
        const endpoint = `/api/products${queryString ? `?${queryString}` : ''}`;
        
        return apiClient.get(endpoint);
    },

    async getProduct(id) {
        return apiClient.get(`/api/products/${id}`);
    },

    async getProductCategories(cityId) {
        const params = cityId ? `?cityId=${cityId}` : '';
        return apiClient.get(`/api/products/categories${params}`);
    },

    async getFeaturedItems() {
        return apiClient.get('/api/featured-items');
    },

    async getProductBatch(ids) {
        const idsString = Array.isArray(ids) ? ids.join(',') : ids;
        return apiClient.get(`/api/products/batch?ids=${idsString}`);
    },

    async getFavoriteProductDetails(productId) {
        return apiClient.get(`/api/favorites/product-details/${productId}`);
    },
};