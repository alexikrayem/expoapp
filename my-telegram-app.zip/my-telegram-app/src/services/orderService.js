// src/services/orderService.js - Order-specific API calls
import apiClient from './apiClient';

export const orderService = {
    async createOrder(userId) {
        return apiClient.post('/api/orders', { userId });
    },

    async getUserOrders(userId) {
        return apiClient.get(`/api/orders?userId=${userId}`);
    },
};