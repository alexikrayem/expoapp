// src/services/cartService.js - Cart-specific API calls
import apiClient from './apiClient';

export const cartService = {
    async getCart(userId) {
        return apiClient.get(`/api/cart?userId=${userId}`);
    },

    async addToCart(userId, productId, quantity = 1) {
        return apiClient.post('/api/cart', {
            userId,
            productId,
            quantity,
        });
    },

    async updateCartItem(productId, userId, newQuantity) {
        return apiClient.put(`/api/cart/item/${productId}?userId=${userId}`, {
            newQuantity,
        });
    },

    async removeCartItem(productId, userId) {
        return apiClient.delete(`/api/cart/item/${productId}?userId=${userId}`);
    },
};