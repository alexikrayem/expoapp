// routes/favorites.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get user favorites
router.get('/', async (req, res) => {
    try {
        const { userId } = req.query;
        
        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }
        
        const query = 'SELECT product_id FROM user_favorites WHERE user_id = $1';
        const result = await db.query(query, [userId]);
        
        const favoriteIds = result.rows.map(row => row.product_id);
        res.json(favoriteIds);
        
    } catch (error) {
        console.error('Error fetching favorites:', error);
        res.status(500).json({ error: 'Failed to fetch favorites' });
    }
});

// Add to favorites
router.post('/', async (req, res) => {
    try {
        const { userId, productId } = req.body;
        
        if (!userId || !productId) {
            return res.status(400).json({ error: 'User ID and Product ID are required' });
        }
        
        // Check if already exists
        const existingQuery = 'SELECT * FROM user_favorites WHERE user_id = $1 AND product_id = $2';
        const existingResult = await db.query(existingQuery, [userId, productId]);
        
        if (existingResult.rows.length === 0) {
            const insertQuery = 'INSERT INTO user_favorites (user_id, product_id) VALUES ($1, $2)';
            await db.query(insertQuery, [userId, productId]);
        }
        
        res.json({ message: 'Added to favorites successfully' });
        
    } catch (error) {
        console.error('Error adding to favorites:', error);
        res.status(500).json({ error: 'Failed to add to favorites' });
    }
});

// Remove from favorites
router.delete('/:productId', async (req, res) => {
    try {
        const { productId } = req.params;
        const { userId } = req.query;
        
        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }
        
        const deleteQuery = 'DELETE FROM user_favorites WHERE user_id = $1 AND product_id = $2';
        await db.query(deleteQuery, [userId, productId]);
        
        res.json({ message: 'Removed from favorites successfully' });
        
    } catch (error) {
        console.error('Error removing from favorites:', error);
        res.status(500).json({ error: 'Failed to remove from favorites' });
    }
});

// Get favorite product details with alternatives
router.get('/product-details/:productId', async (req, res) => {
    try {
        const { productId } = req.params;
        
        // Get the original product
        const productQuery = `
            SELECT 
                p.*,
                s.name as supplier_name,
                s.location as supplier_location,
                CASE 
                    WHEN p.is_on_sale = true AND p.discount_price IS NOT NULL 
                    THEN p.discount_price 
                    ELSE p.price 
                END as effective_selling_price
            FROM products p
            JOIN suppliers s ON p.supplier_id = s.id
            WHERE p.id = $1
        `;
        
        const productResult = await db.query(productQuery, [productId]);
        
        if (productResult.rows.length === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }
        
        const product = productResult.rows[0];
        const isAvailable = product.stock_level > 0 && product.is_active;
        
        // Find alternatives if not available
        let alternatives = [];
        if (!isAvailable) {
            const alternativesQuery = `
                SELECT 
                    p.*,
                    s.name as supplier_name,
                    CASE 
                        WHEN p.is_on_sale = true AND p.discount_price IS NOT NULL 
                        THEN p.discount_price 
                        ELSE p.price 
                    END as effective_selling_price
                FROM products p
                JOIN suppliers s ON p.supplier_id = s.id
                WHERE p.standardized_name_input ILIKE $1 
                AND p.id != $2 
                AND p.is_active = true 
                AND p.stock_level > 0
                ORDER BY p.price ASC
                LIMIT 3
            `;
            
            const alternativesResult = await db.query(alternativesQuery, [
                product.standardized_name_input,
                productId
            ]);
            
            alternatives = alternativesResult.rows;
        }
        
        res.json({
            originalProduct: product,
            isAvailable,
            alternatives
        });
        
    } catch (error) {
        console.error('Error fetching favorite product details:', error);
        res.status(500).json({ error: 'Failed to fetch product details' });
    }
});

module.exports = router;