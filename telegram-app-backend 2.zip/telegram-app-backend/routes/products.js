// routes/products.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get all products with filtering, search, and pagination
router.get('/', async (req, res) => {
    try {
        const {
            page = 1,
            limit = 12,
            cityId,
            category,
            searchTerm,
            minPrice,
            maxPrice,
            onSale
        } = req.query;

        const offset = (parseInt(page) - 1) * parseInt(limit);
        
        let whereConditions = ['p.is_active = true', 's.is_active = true'];
        let queryParams = [];
        let paramIndex = 1;

        // City filter
        if (cityId) {
            whereConditions.push(`s.city_id = $${paramIndex}`);
            queryParams.push(cityId);
            paramIndex++;
        }

        // Category filter
        if (category && category !== 'all') {
            whereConditions.push(`p.category ILIKE $${paramIndex}`);
            queryParams.push(`%${category}%`);
            paramIndex++;
        }

        // Search filter
        if (searchTerm) {
            whereConditions.push(`(p.name ILIKE $${paramIndex} OR p.description ILIKE $${paramIndex} OR p.standardized_name_input ILIKE $${paramIndex})`);
            queryParams.push(`%${searchTerm}%`);
            paramIndex++;
        }

        // Price range filters
        if (minPrice) {
            whereConditions.push(`p.price >= $${paramIndex}`);
            queryParams.push(parseFloat(minPrice));
            paramIndex++;
        }

        if (maxPrice) {
            whereConditions.push(`p.price <= $${paramIndex}`);
            queryParams.push(parseFloat(maxPrice));
            paramIndex++;
        }

        // On sale filter
        if (onSale === 'true') {
            whereConditions.push('p.is_on_sale = true AND p.discount_price IS NOT NULL');
        }

        const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';

        // Main query for products
        const productsQuery = `
            SELECT 
                p.*,
                s.name as supplier_name,
                s.location as supplier_location,
                CASE 
                    WHEN p.is_on_sale = true AND p.discount_price IS NOT NULL 
                    THEN p.discount_price 
                    ELSE p.price 
                END as effective_selling_price
            FROM products p
            JOIN suppliers s ON p.supplier_id = s.id
            ${whereClause}
            ORDER BY p.created_at DESC
            LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
        `;

        queryParams.push(parseInt(limit), offset);

        // Count query for pagination
        const countQuery = `
            SELECT COUNT(*) as total
            FROM products p
            JOIN suppliers s ON p.supplier_id = s.id
            ${whereClause}
        `;

        const countParams = queryParams.slice(0, -2); // Remove limit and offset for count

        const [productsResult, countResult] = await Promise.all([
            db.query(productsQuery, queryParams),
            db.query(countQuery, countParams)
        ]);

        const totalItems = parseInt(countResult.rows[0].total);
        const totalPages = Math.ceil(totalItems / parseInt(limit));

        res.json({
            items: productsResult.rows,
            currentPage: parseInt(page),
            totalPages,
            totalItems,
            limit: parseInt(limit)
        });

    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ error: 'Failed to fetch products' });
    }
});

// Get product categories for filter options
router.get('/categories', async (req, res) => {
    try {
        const { cityId } = req.query;
        
        let query = `
            SELECT 
                p.category,
                COUNT(*) as product_count
            FROM products p
            JOIN suppliers s ON p.supplier_id = s.id
            WHERE p.is_active = true AND s.is_active = true
        `;
        
        const queryParams = [];
        
        if (cityId) {
            query += ' AND s.city_id = $1';
            queryParams.push(cityId);
        }
        
        query += `
            GROUP BY p.category
            HAVING COUNT(*) > 0
            ORDER BY product_count DESC, p.category ASC
        `;

        const result = await db.query(query, queryParams);
        
        res.json({
            categories: result.rows
        });

    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({ error: 'Failed to fetch categories' });
    }
});

// Get products by batch of IDs (for favorites)
router.get('/batch', async (req, res) => {
    try {
        const { ids } = req.query;
        
        if (!ids) {
            return res.json([]);
        }

        const productIds = ids.split(',').map(id => parseInt(id)).filter(id => !isNaN(id));
        
        if (productIds.length === 0) {
            return res.json([]);
        }

        const placeholders = productIds.map((_, index) => `$${index + 1}`).join(',');
        
        const query = `
            SELECT 
                p.*,
                s.name as supplier_name,
                s.location as supplier_location,
                CASE 
                    WHEN p.is_on_sale = true AND p.discount_price IS NOT NULL 
                    THEN p.discount_price 
                    ELSE p.price 
                END as effective_selling_price
            FROM products p
            JOIN suppliers s ON p.supplier_id = s.id
            WHERE p.id IN (${placeholders}) AND p.is_active = true
            ORDER BY p.created_at DESC
        `;

        const result = await db.query(query, productIds);
        res.json(result.rows);

    } catch (error) {
        console.error('Error fetching products batch:', error);
        res.status(500).json({ error: 'Failed to fetch products' });
    }
});

// Get individual product by ID
router.get('/:id', async (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        
        if (isNaN(productId)) {
            return res.status(400).json({ error: 'Invalid product ID' });
        }

        const query = `
            SELECT 
                p.*,
                s.name as supplier_name,
                s.location as supplier_location,
                CASE 
                    WHEN p.is_on_sale = true AND p.discount_price IS NOT NULL 
                    THEN p.discount_price 
                    ELSE p.price 
                END as effective_selling_price
            FROM products p
            JOIN suppliers s ON p.supplier_id = s.id
            WHERE p.id = $1 AND p.is_active = true
        `;

        const result = await db.query(query, [productId]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }

        res.json(result.rows[0]);

    } catch (error) {
        console.error('Error fetching product:', error);
        res.status(500).json({ error: 'Failed to fetch product' });
    }
});

module.exports = router;